def leap_year(): y=int(input());print("Yes" if y%400==0 else "No" if y%100==0 else "Yes" if y%4==0 else "No")



if __name__=="__main__":
    leap_year()    

        
